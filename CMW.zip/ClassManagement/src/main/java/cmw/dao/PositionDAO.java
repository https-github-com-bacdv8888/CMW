package cmw.dao;

public interface PositionDAO {

}
