package cmw.dao;

public class PointDAOImpl implements PointDAO{

}
