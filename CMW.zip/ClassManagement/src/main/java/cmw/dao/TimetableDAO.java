package cmw.dao;

public interface TimetableDAO {

}
