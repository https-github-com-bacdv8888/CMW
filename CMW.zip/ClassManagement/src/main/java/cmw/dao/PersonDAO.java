package cmw.dao;

public interface PersonDAO {

}
