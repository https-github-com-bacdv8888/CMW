package cmw.dao;

public class ClassDAOImpl implements ClassDAO{

}
