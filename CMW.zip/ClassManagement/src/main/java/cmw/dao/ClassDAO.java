package cmw.dao;

public interface ClassDAO {

}
