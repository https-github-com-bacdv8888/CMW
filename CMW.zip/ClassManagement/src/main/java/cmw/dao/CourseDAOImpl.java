package cmw.dao;

public class CourseDAOImpl implements CourseDAO {

}
