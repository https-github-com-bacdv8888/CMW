package cmw.dao;

public interface CourseDAO {

}
