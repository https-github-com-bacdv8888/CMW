package cmw.dao;

public class SubjectDAOImpl implements SubjectDAO {

}
