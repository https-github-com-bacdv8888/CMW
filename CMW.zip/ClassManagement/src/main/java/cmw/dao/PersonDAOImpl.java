package cmw.dao;

public class PersonDAOImpl implements PersonDAO {

}
