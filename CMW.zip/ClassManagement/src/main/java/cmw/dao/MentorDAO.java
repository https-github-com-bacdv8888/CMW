package cmw.dao;

public interface MentorDAO {

}
