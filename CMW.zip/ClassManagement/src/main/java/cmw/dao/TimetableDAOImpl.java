package cmw.dao;

public class TimetableDAOImpl implements TimetableDAO{

}
