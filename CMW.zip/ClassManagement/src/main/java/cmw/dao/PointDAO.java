package cmw.dao;

public interface PointDAO {

}
