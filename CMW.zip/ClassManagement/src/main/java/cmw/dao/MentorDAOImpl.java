package cmw.dao;

public class MentorDAOImpl implements MentorDAO{

}
