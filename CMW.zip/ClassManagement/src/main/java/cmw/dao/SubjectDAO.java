package cmw.dao;

public interface SubjectDAO {

}
